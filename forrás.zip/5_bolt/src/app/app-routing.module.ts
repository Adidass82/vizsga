import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ProductComponent } from './product/product.component';
import { NavComponent } from './nav/nav.component';




const routes: Routes = [
  {path:'product', component:ProductComponent},
  {path:'login', component:LoginComponent},
  {path:'nav', component:NavComponent},
  {path:'**', redirectTo:"nav",pathMatch:"full"}
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
